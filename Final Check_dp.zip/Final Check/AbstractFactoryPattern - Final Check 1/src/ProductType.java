public enum ProductType {
	
	ELECTRONIC,FURNITURE,TOY
}