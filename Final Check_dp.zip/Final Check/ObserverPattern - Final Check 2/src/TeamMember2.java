public class TeamMember2 implements INotificationObserver{
	
	
	@Override
	public void OnBooking() {
		// TODO Auto-generated method stub
		System.out.println("Member 2 received message");
	}

}