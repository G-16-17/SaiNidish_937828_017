public interface INotificationObserver {

	
	public void OnBooking();
	
}