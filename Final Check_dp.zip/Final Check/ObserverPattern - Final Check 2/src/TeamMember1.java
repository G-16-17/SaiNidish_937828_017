public class TeamMember1 implements INotificationObserver{

	
	
	@Override
	public void OnBooking() {
		// TODO Auto-generated method stub
		System.out.println("Member 1 received message");
	}


}